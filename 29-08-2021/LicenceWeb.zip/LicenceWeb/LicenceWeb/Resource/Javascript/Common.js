﻿var ApiServerPath = "http://localhost:6009/";

var UserName = "SuperAdmin";
var Password = "SuperAdmin";